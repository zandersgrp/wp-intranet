<?php
/**
 * Plugin Name: Intranet Roles
 * Description: Plugin to manage custom roles for the intranet system.
 * Version: 1.0
 * Author: Your Name
 */

// Include role creation logic.
require_once __DIR__ . '/includes/create-roles.php';